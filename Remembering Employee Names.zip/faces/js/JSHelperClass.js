class JSHelper {

  constructor() {

    this.SPLIT_TOKEN = "^^^^";

  }

  center(obj) {
    return "<center>" + obj + "</center>";
  }

  clear(Id) {

    for (var i = 0; i < arguments.length; i++) {
      $('#' + arguments[i]).empty();
      this.Debug(arguments[i]);
    }

  }

  notUsedclearSelectBox(Id) {
    $('#' + Id).empty();
  }

  callerName() {
    try {
      throw new Error();
    } catch (e) {
      try {
        return e.stack.split('at ')[3].split(' ')[0];
      } catch (e) {
        return '';
      }
    }

  }

  Warning(m, isOff) {

    let c = this.callerName();

    if (isOff == undefined)
      log.warning(c + ":" + m);
  }

  Debug(m, isOff) {

    let c = this.callerName();

    if (isOff == undefined)
      log.debug(c + ":" + m);
  }

  Info(m, isOff) {

    let c = this.callerName();

    if (isOff == undefined)
      log.info(c + ":" + m);
  }

  Error(m, isOff) {

    let c = this.callerName();

    if (isOff == undefined)
      log.error(c + ":" + m);
  }

  logger(m, isOff) {

    let c = this.callerName();

    if (isOff == undefined)
      console.log("logger:" + c + ":" + m);

  }

  hide() {
    for (var i = 0; i < arguments.length; i++) {
      $('#' + arguments[i]).hide();
      this.Debug(arguments[i]);
    }
  }

  show() {
    for (var i = 0; i < arguments.length; i++) {
      $('#' + arguments[i]).show();
      this.Debug(arguments[i]);
    }
  }

  fill(Id, content, klass) {

    try {

      $("#" + Id).html(content);

      if (klass != undefined) {
        assignClass(Id, klass);
      }

    } catch (err) {}

  }

  assignClass(Id, klass) {
    $("#" + Id).addClass(klass);
  }

  removeClass(Id, klass) {
    $("#" + Id).removeClass(klass);
  }

  execute(wsUrl, parameterObject, method2CallAfterwards, actionz) {

    console.log(wsUrl, true);

    try {

      let actionType = (actionz == undefined ? "GET" : "POST");

      $.ajax({

        type: actionType,
        url: wsUrl,
        data: {
          parameter: parameterObject
        },
        dataType: "json",
        contentType: "application/json",
        timeout: 0,

        success: function (data) {
          eval(method2CallAfterwards);
        }
      });

    } catch (err) {
      console.log(err);
    }

  }

  contains(strIn, search4) {
    try {
      if (strIn.indexOf(search4) > -1) return true;
    } catch (err) {
      return false;
    }
    return false;
  }

  remove(Id) {
    $("#" + Id).remove();
  }

  empty() {
    for (var i = 0; i < arguments.length; i++) {
      $('#' + arguments[i]).html("");
    }
  }

  setValue(Id, value) {
    $("#" + Id).val(value);
  }

  append(Id, content) {
    $("#" + Id).append(content);
  }

  scroll2Id(Id) {
    try {
      document.getElementById(Id).scrollIntoView();
    } catch (err) {}
  }


  move(oldDIV, newDIV) {

    let content = this.get(oldDIV);

    this.remove(oldDIV);

    this.fill(newDIV, content);
  }

  get(id) {
    return $("#" + id).html();
  }

  goto(url) {
    window.location.replace(url);
  }

  getSelectBoxText(Id) {
    return $("#" + Id + " option:selected").text();
  }

  newBrowserTab(url) {
    window.open(url);
  }

  getLink(Id, onclick, text, klass, fillObj) {

    let i_ = (Id.length == 0 ? "" : ' id="' + Id + '"');

    let k_ = (klass == undefined ? "" : ' class="' + klass + '"');

    let lnk = "";

    if (onclick == undefined) {
      lnk = '<a href="#" ' + i_ + ' ' + k_ + ' >' + text + '</a>';
    } else {
      lnk = '<a href="#" ' + i_ + ' ' + k_ + ' onclick="' + onclick + '">' + text + '</a>';
    }

    if (fillObj != undefined)
      this.append(fillObj, lnk);

    console.log(fillObj);

    return lnk;

  }

  getValue(Id) {
    return $("#" + Id).val();
  }

  //http://bootboxjs.com/examples.html
  confirm(question_, callBackFunc, s_) {

    let size_ = (s_ == undefined ? "small" : s_);

    bootbox.confirm({
      message: question_,
      size: size_,
      buttons: {
        confirm: {
          label: 'Yes',
          className: 'btn-success'
        },
        cancel: {
          label: 'No',
          className: 'btn-danger'
        }
      },
      callback: function (result) {
        eval(callBackFunc);
      }
    });

  }

  getUrlPath() {
    return window.location.pathname;
  }

  getCurrentYear() {
    return new Date().getFullYear();
  }

  prepend(Id, content) {
    $("#" + Id).prepend(content);
  }

  getRandomNumber() {
    return Math.floor((Math.random() * 10000000) + 1);
  }

  getQueryParameter(name) {
    var match = RegExp('[?&]' + name + '=([^&]*)').exec(window.location.search);
    return match && decodeURIComponent(match[1].replace(/\+/g, ' '));
  }

  div(Id, content, klass,title) {

    let id = (Id == "" ? "" : ' id="' + Id + '"');

    let k = (klass == undefined ? "" : ' class="' + klass + '"');

    let t = (title == undefined ? "" : ' title="' + title + '"');

    return '<div ' + id + k + t + '>' + content + '</div>';
  }

  image(Id,imagePath, klick, klass) {

    if (imagePath == null) return "";

    let id = (Id == "" ? "" : ' id="' + Id + '"');

    let klick_ = (klick == undefined ? "" : ' onclick="' + klick + '"');

    let k_ = (klass == undefined ? "" : ' class="' + klass + '"');

    return '<img ' + id + ' style="height: 100%; width: 100%; object-fit: contain" ' + klick_ + ' ' + k_ + ' src="' + imagePath + '" border="0">';

  }

  reloadPage() {
    location.reload(true);
  }

  property(Id, prop, value) {

    try {
      $('#' + Id).prop(prop, value);
    } catch (err) {
      console.log(err);
    }
  }

  attribute(Id, Attribute, value) {

    try {
      $('#' + Id).css(Attribute, value);
    } catch (err) {
      console.log(err);
    }
  }

  getRandomNumber() {
    return Math.floor((Math.random() * 10000000) + 1);
  }

  randomAlphaLetters() {

    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 15; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
  }

  getRandomVariableName() {

    return this.randomAlphaLetters() + this.getRandomNumber();

  }

  find(str, find) {
    if (str.search(find) == -1)
      return false;
    return true;
  }

  replace(str, wht, wth) {
    return str.replace(wht, wth);
  }

  focus(Id) {
    document.getElementById(Id).focus();
  }

  click(Id) {
    $("#" + Id).trigger("click");
  }

  convertMS(ms) {
    var d, h, m, s;
    s = Math.floor(ms / 1000);
    m = Math.floor(s / 60);
    s = s % 60;
    h = Math.floor(m / 60);
    m = m % 60;
    d = Math.floor(h / 24);
    h = h % 24;
    h += d * 24;
    //return h + ':' + m + ':' + s;
    return m + ':' + s;
}

getTime(){
  return new Date().toLocaleTimeString()
}

getTimer(Id){
  return setInterval(function() {
    let d = new Date();
    document.getElementById(Id).innerHTML = d.toLocaleTimeString();
  }, 1000);
}

} //class: