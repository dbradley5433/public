/*
Instructions:
1. zip content into any directory.
2. open terminal/command-line.
3. run:python3 -m http.server 9000
4. open browser and paste:http://localhost:9000/#

to turn on debugger change false to true: 
    log4javascript.setEnabled(false);

to test:

click "start game"

to test filter:
enter "Matt" or any other string and click start game. Filtered employees will be listed.

to test hints: click on hints. 

to test hot-keys click keyboard link & press 1-5 numbers. toggles off/on.

*/

var jsHelpers = new JSHelper();

var faces   = new jsFaces();

/* turn debug off/on */
log4javascript.setEnabled(false);

var log = log4javascript.getLogger("main");

var appender = new log4javascript.InPageAppender();

log.addAppender(appender);

var people = {}

var timer = jsHelpers.getTimer("right_MainTime");

function setupApplication(){

    jsHelpers.Debug("setupApplication()");

    jsHelpers.execute("https://willowtreeapps.com/api/v1.0/profiles/","", "faces.load(data)","POST");
    
    setupMenu();
}

function setupMenu(){

    jsHelpers.getLink("","loadImages()","Start Game","", "playGame");
    
    jsHelpers.getLink("","location.reload();faces.reset();","Reset Game","", "resetGame");
    
    jsHelpers.getLink("","toggleKeyboard()","Keyboard:","", "toggleKB");

    jsHelpers.append("toggleKB",jsHelpers.div("kbStatus","Off"));

    jsHelpers.getLink("","hints()","Hints","", "hints");

    jsHelpers.hide("hints","toggleKB");

}

function loadImages(){

    setupStatsBox();

    faces.currentPicks.length = 0;

    for(var i=0;i<5;i++){

        let pick = validatePerson();

        jsHelpers.Debug("returned pick:" + pick);

        /* all filtered faces have been found. */
        if(pick == 0) continue;

        //add to current picks:
        faces.currentPicks.push(pick);
    }

    for(var i=0;i<faces.currentPicks.length;i++){

        let pick = faces.currentPicks[i];

        img = getImage(i,pick,faces.people[pick].headshot.url);

        jsHelpers.fill("pic_" + i,img);

    }

    faces.selected = faces.currentPicks[getRandomInt(faces.currentPicks.length)];

    jsHelpers.Debug(faces.currentPicks);

    jsHelpers.Debug("selected:" + faces.selected);
    jsHelpers.Debug("Pick List:" + faces.currentPicks);

    jsHelpers.fill("selectedPic",faces.getName() + "?");

    bootbox.alert("We're looking for " + faces.getName());
}

function validatePerson(){
    
    let pick = 0;
    let matched = false;

    for(var i=1;i< faces.people.length;i++){

        pick = getRandomInt(faces.people.length);

        //eliminate duplicate picks:
        if(faces.currentPicks.includes(pick))
            continue;

        try{
            //still employed:
            if(faces.people[pick].jobTitle.length > 0){
                
                //filter option:
                name     = faces.getName(pick);
                filterOp = jsHelpers.getValue("filter");

                if(filterOp.length > 0){
                    if(name.startsWith(filterOp)){  
                        jsHelpers.Debug("Picked:" + pick + ":" + name);
                        jsHelpers.Debug("Picked:" + pick + ":" + faces.people[pick].jobTitle);
                        matched = true;
                        break;
                    }
                }
                else {
                    matched = true;
                    break;
                }    
            } 
        } catch(err){
            jsHelpers.Error("title doesn't exist");
        }
    }

    return (matched == true ? pick : 0);
}

function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
}

function getImage(Id,pick,backGround){

    if(backGround == undefined) return "";

    let container = "";

    try{

        container = jsHelpers.image("img_" + Id,"https:" + backGround,"checkStatistics(" + pick + ")","backGroundContainer");

    } catch(err){}

    jsHelpers.Debug(container);

    return container;
}

function setupStatsBox(){

    jsHelpers.show("statsBox","hints","toggleKB");

    /*reset totals */
    jsHelpers.empty("hits","misses","end","elapse");

    /* remove images */
    jsHelpers.empty("pic_0","pic_1","pic_2","pic_3","pic_4");

    //reset totals:
    faces.initializeTotals();

    faces.startTime = new Date().getTime();

    jsHelpers.fill("start",jsHelpers.getTime());

}

function checkStatistics(pick){

   faces.chk4Match(pick);

   jsHelpers.fill("hits",faces.hits);
   jsHelpers.fill("misses",faces.misses);

   jsHelpers.fill("totalHits",faces.runningHits);
   jsHelpers.fill("totalMisses",faces.runningmisses);

   jsHelpers.fill("totalAvgMisses",(faces.runningHits/faces.runningmisses).toFixed(2));

   showDetails(pick);
}

function showDetails(pick){

    for(let i=0;i<faces.currentPicks.length;i++){
        if(faces.currentPicks[i] == pick){
            jsHelpers.append("pic_" + i,faces.getName(faces.currentPicks[i]) + "</br>");
            jsHelpers.append("pic_" + i,faces.people[faces.currentPicks[i]].jobTitle);
        }
    }

}

let imagesDisplayed = [];
let selectedImage   = 0;

function hints() {
    
    imagesDisplayed.length = 0;

    for(let i=0;i<faces.currentPicks.length;i++){
        if (faces.currentPicks[i] != faces.selected)
            imagesDisplayed.push(i);
        else selectedImage = i;    
    }

    let hm = setInterval(function () {
        
        let pick = imagesDisplayed[0];
        
        jsHelpers.Debug("pick:img_" + pick);

        jsHelpers.hide("img_" + pick);
        
    
        jsHelpers.Debug("imagesDisplayed:" + imagesDisplayed);
    
        jsHelpers.Debug("countImaged:" + imagesDisplayed.length);

        if(imagesDisplayed.length == 0){
            jsHelpers.Debug("stoping... hints");
            jsHelpers.click("img_" + selectedImage);
            clearInterval(hm);
        }

        imagesDisplayed.shift();
    
    }, 3000);
}

//https://keycode.info/
let keyboardMode = false;

function toggleKeyboard(){
    keyboardMode = (keyboardMode == true ? false : true);
    if(keyboardMode) jsHelpers.fill("kbStatus","On"); else jsHelpers.fill("kbStatus","Off");
}

document.onkeyup = function(e) {
    try{
        if(keyboardMode){
            if(e.which >=49 && e.which <=53)
                jsHelpers.click("img_" + (e.which - 49));
        }
    } catch(err){}
}//onkeyup event: