
class jsFaces {

    constructor() {
        this.people = {};
        this.currentPicks = [];
        this.selected = 0;
        this.hits     = 0;
        this.misses   = 0;

        this.startTime = 0;
        this.endTime   = 0;
        this.lapse     = 0;

        this.runningHits       = 0;
        this.runningmisses     = 0;
        this.runningNumOfGames = 0;

        /* don't have time to use these */
        this.runningStartTime  = [];
        this.runningEndTime    = [];

        this.runningelapse     = 0;

    }

    reset(){
        this.initializeRunningTotals();
        this.initializeTotals();
    }

    initializeTotals(){

        this.currentPicks = [];
        this.selected  = 0;
        this.hits      = 0;
        this.misses    = 0;

        this.startTime = 0;
        this.endTime   = 0;
        this.lapse     = 0;

    }

    initializeRunningTotals(){

        this.runningHits       = 0;
        this.runningmisses     = 0;
        this.runningNumOfGames = 0;
        this.runningStartTime  = [];
        this.runningEndTime    = [];

        this.runningelapse     = 0;

    }
    
    getName(Id){
        let personId = (Id == undefined ? this.selected : Id);
        return this.people[personId].firstName + " " + this.people[personId].lastName;
    }

    load(data){
        this.people = data;
    }

    chk4Match(personPicked){

        if(this.hits != 0){
            bootbox.alert("Please start new game.");
            return;
        }

        if(personPicked == this.selected){

           bootbox.alert("you are correct!");

           this.hits ++;
           this.runningHits ++;

           this.endTime = new Date().getTime();
           
           this.runningEndTime.push(this.endTime);

           this.lapse = (this.endTime-this.startTime);
           
           this.runningelapse = this.runningelapse + this.lapse;

           jsHelpers.fill("end",jsHelpers.getTime());
           jsHelpers.fill("elapse",jsHelpers.convertMS(this.lapse));

           jsHelpers.fill("totalElapse",jsHelpers.convertMS(this.runningelapse));
           jsHelpers.fill("totalAvgElapse",jsHelpers.convertMS((this.runningelapse/this.runningHits).toFixed(0)));

           jsHelpers.hide("hints","toggleKB");

        } else{
            this.misses ++;
            this.runningmisses ++;
        }

    }

    fillStats(){

    }

}//class: